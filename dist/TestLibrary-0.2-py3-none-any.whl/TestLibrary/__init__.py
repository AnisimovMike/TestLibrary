def foo(): return 100
