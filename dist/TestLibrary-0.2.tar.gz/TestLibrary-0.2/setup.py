from setuptools import setup


setup(
    name='TestLibrary',                    # package name
    version='0.2',                          # version
    description='Package Description will be later',      # short description
    url='https://github.com/AnisimovMike/TestLibrary',               # package URL
    install_requires=[],                    # list of packages this package depends
                                            # on.
    packages=['TestLibrary'],              # List of module names that installing
                                            # this package will provide.
)
